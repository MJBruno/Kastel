use crate::bytecode::chunk::OpCode;
use crate::error::compile_error::CompileError;
use crate::frontend::ast::Expression;

use super::compiler::Compiler;
use super::variables::Global;

impl Compiler {
    // ============================================================
    //                      VARIABLES DECLARATION
    // ============================================================

    pub(crate) fn compile_var(
        &mut self,
        name: &str,
        initializer: Option<&Expression>,
        mutable: bool,
    ) -> Result<(), CompileError> {
        if self.in_function || self.scope_depth > 0 {
            self.compile_local_var(name, initializer, mutable)
        } else {
            self.compile_global_var(name, initializer, mutable)
        }
    }

    pub(crate) fn compile_local_var(
        &mut self,
        name: &str,
        initializer: Option<&Expression>,
        mutable: bool,
    ) -> Result<(), CompileError> {
        let slot =
            self.context
                .borrow_mut()
                .locals
                .declare_local(name, self.scope_depth, mutable)?;

        match initializer {
            Some(expr) => {
                self.compile_expression(expr)?;
            }

            None => {
                self.emit_opcode(OpCode::None);
            }
        }

        self.context
            .borrow_mut()
            .locals
            .mark_initialized(self.scope_depth);

        debug_assert_eq!(self.context.borrow().locals.len() - 1, slot as usize);

        Ok(())
    }

    pub(crate) fn compile_global_var(
        &mut self,
        name: &str,
        initializer: Option<&Expression>,
        mutable: bool,
    ) -> Result<(), CompileError> {
        let existing = self.globals.borrow().get(name).cloned();

        if let Some(global) = existing {
            if !global.native {
                return Err(CompileError::VariableAlreadyDeclared(name.to_string()));
            }
        }

        let name_constant = self.identifier_constant(name)?;

        match initializer {
            Some(expr) => {
                self.compile_expression(expr)?;
            }

            None => {
                self.emit_opcode(OpCode::None);
            }
        }

        self.emit_bytes(OpCode::DefineGlobal, name_constant);

        self.globals.borrow_mut().insert(
            name.to_string(),
            Global {
                constant: name_constant,
                mutable,
                native: false,
            },
        );

        Ok(())
    }

    // ============================================================
    //                      PARAMÈTRES
    // ============================================================

    pub(crate) fn add_parametre(&mut self, name: &str) -> Result<(), CompileError> {
        if self.function_arity == u8::MAX {
            return Err(CompileError::TooManyArguments);
        }

        let slot = self
            .context
            .borrow_mut()
            .locals
            .declare_local(name, self.scope_depth, true)?;

        self.context
            .borrow_mut()
            .locals
            .mark_initialized(self.scope_depth);

        debug_assert_eq!(slot, self.function_arity);

        self.function_arity += 1;

        Ok(())
    }

    pub(crate) fn declare_existing_local(
        &mut self,
        name: &str,
        mutable: bool,
    ) -> Result<u8, CompileError> {
        let slot =
            self.context
                .borrow_mut()
                .locals
                .declare_local(name, self.scope_depth, mutable)?;

        self.context
            .borrow_mut()
            .locals
            .mark_initialized(self.scope_depth);

        Ok(slot)
    }
}
