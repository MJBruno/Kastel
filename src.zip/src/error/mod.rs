pub mod lex_error;
pub mod parse_error;
pub mod compile_error;
pub mod runtime_error;
pub mod kastel_error;
pub mod machine_error;
pub mod suggest;