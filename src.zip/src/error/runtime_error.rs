use crate::runtime::value::Value;

// ================================================================
// RUNTIME_ERROR
// ================================================================

#[derive(Debug, Clone)]
pub enum RuntimeError {
    TypeError,
    DivisionByZero,

    WrongArgumentCount {
        expected: usize,
        found: usize,
    },

    NotCallable,
    InvalidFunction,
    NativeError,

    IndexOutOfBounds,

    ArrayIndexNotInteger,

    ArrayIndexOutOfBounds {
        index: usize,
        length: usize,
    },

    NotIndexable,
    NotObject,

    /// Tentative de mutation d'une valeur immuable (ex. `tuple[0] = x`).
    /// Porte le nom du type concerné pour le message d'erreur.
    ImmutableValue(&'static str),

    ModuleError(String),

    ObjectFieldNotFound {
        name: String,
        suggestion: Option<String>,
    },

    NotIterable,
    IteratorExhausted,
    InvalidShiftAmount,

    WithLocation {
        line: usize,
        column: usize,
        source: Box<RuntimeError>,
    },

    StackUnderflow,
    InvalidOpcode(u8),

    // ============================================================
    // EXCEPTION KASTEL
    // ============================================================

    /*
     * Exception explicitement lancée par :
     *
     *     throw value;
     *
     * La valeur peut être n'importe quelle Value Kastel :
     *
     *     throw "boom";
     *     throw 42;
     *     throw [1, 2, 3];
     *     throw { message: "boom" };
     */
    Thrown(Value),

    InterfaceMethodMissing {
        interface: String,
        method: String,
    },

    InterfaceMethodArityMismatch {
        interface: String,
        method: String,
        expected: usize,
        found: usize,
    },
}

impl std::fmt::Display for RuntimeError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            RuntimeError::TypeError => {
                write!(f, "Operand must be numbers.")
            }

            RuntimeError::DivisionByZero => {
                write!(f, "Division by zero.")
            }

            RuntimeError::WrongArgumentCount { expected, found } => {
                write!(f, "Expected {expected} arguments but found {found}.")
            }

            RuntimeError::NotCallable => {
                write!(f, "Value is not callable.")
            }

            RuntimeError::InvalidFunction => {
                write!(f, "Invalid function.")
            }

            RuntimeError::NativeError => {
                write!(f, "Native function error.")
            }

            RuntimeError::ArrayIndexNotInteger => {
                write!(f, "Array index must be an integer.")
            }

            RuntimeError::ArrayIndexOutOfBounds { index, length } => {
                write!(f, "Array index {index} out of bounds for length {length}.")
            }

            RuntimeError::IndexOutOfBounds => {
                write!(f, "Array index out of bounds")
            }

            RuntimeError::ModuleError(message) => {
                write!(f, "Module error: {message}")
            }

            RuntimeError::ObjectFieldNotFound { name, suggestion } => match suggestion {
                Some(suggestion) => write!(
                    f,
                    "Champ '{name}' introuvable sur l'objet. Vouliez-vous dire '{suggestion}' ?"
                ),

                None => write!(f, "Champ '{name}' introuvable sur l'objet."),
            },

            RuntimeError::NotIterable => {
                write!(
                    f,
                    "Cette valeur n'est pas itérable (utilisable dans un 'for..in')."
                )
            }

            RuntimeError::IteratorExhausted => {
                write!(f, "Itérateur déjà épuisé.")
            }

            RuntimeError::InvalidShiftAmount => {
                write!(f, "Décalage invalide : doit être compris entre 0 et 63.")
            }

            RuntimeError::WithLocation {
                line,
                column,
                source,
            } => {
                write!(f, "ligne {line}, colonne {column} : {source}")
            }

            RuntimeError::NotIndexable => {
                write!(f, "Value is not indexable.")
            }

            RuntimeError::NotObject => {
                write!(f, "Value is not an object.")
            }

            RuntimeError::ImmutableValue(type_name) => {
                write!(
                    f,
                    "Impossible de modifier une valeur de type '{type_name}' : elle est immuable."
                )
            }

            RuntimeError::StackUnderflow => {
                write!(f, "VM stack underflow.")
            }

            RuntimeError::InvalidOpcode(opcode) => {
                write!(f, "Invalid bytecode opcode: {opcode}.")
            }

            RuntimeError::Thrown(value) => {
                write!(f, "Uncaught exception: {value:?}")
            }

            RuntimeError::InterfaceMethodMissing { interface, method } => {
                write!(f, "Interface '{}' requires method '{}'.", interface, method)
            }

            RuntimeError::InterfaceMethodArityMismatch {
                interface,
                method,
                expected,
                found,
            } => {
                write!(
                    f,
                    "Method '{}' from interface '{}' expects {} arguments but found {}.",
                    method, interface, expected, found
                )
            }
        }
    }
}
